
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Primary Meta Tags -->
<title>Adurah mailer</title>
<meta name="title" content="Adurah mailer" />
<meta name="description" content="Spread your mail across the box built by Tim.Adurah contact on WhatsApp at +2349051547147" />
<link rel="icon" type="image/png" href="./zeee.png">
<!-- Open Graph / Facebook -->
<meta property="og:type" content="website" />
<meta property="og:url" content="https://topkonnect.net/payments/Zelle/" />
<meta property="og:title" content="Adurah mailer" />
<meta property="og:description" content="Spread your mail across the box built by Tim.Adurah contact on WhatsApp at +2349051547147" />
<meta property="og:image" content="./zeee.png" />

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image" />
<meta property="twitter:url" content="https://topkonnect.net/payments/Zelle/" />
<meta property="twitter:title" content="Adurah mailer" />
<meta property="twitter:description" content="Spread your mail across the box built by Tim.Adurah contact on WhatsApp at +2349051547147" />
<meta property="twitter:image" content="./zeee.png" />

<!-- Meta Tags Generated with https://metatags.io -->
</head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>

<style>
    /* your styles go here */
    body {
        font-family: monospace;
    }
</style>

<body>
    <br>
    <br>

    <form class="col-lg-4 col-10 m-auto my-5 bg-light p-5 rounded-3 shadow position-relative"  action="mailer.php">
        <!-- toppic -->

        <div class="my-3 fw-bold diplay-4 p-4 bg-white rounded-3 shadow" style="position:absolute; right:2%; top:-10%;">Adurah mailer</div>

        <span id="result"></span>
        <!-- passwor5d input -->
        <div class="form-outline mb-4">
            <label class="form-label" for="key">Your app key</label>
            <input type="password" id="key" class="bg-light form-control" placeholder="input your app key" />
        </div>
         <!-- email input -->
 <div class="form-outline mb-4">
     <label class="form-label" for="client_mail">client mail</label>
     <input type="email" id="client_mail" class="bg-light form-control" placeholder="mail address" />
 </div>
        <!--reply to input -->
        <div class="form-outline mb-4">
            <label class="form-label" for="client_mail">sender costume mail</label>
            <input type="email" id="reply" class="bg-light form-control" placeholder="like irs.agenvy@sososo.com" />
        </div>
        <!-- format input -->
        <div class="form-outline mb-4">
        <label class="form-label" for="format">format text</label>
            <div type="text" id="format" class="bg-light form-control" contenteditable="true" > Message will gies here  </div>
        </div>
        </div>

        <!-- Submit button -->
        <div type="submit" class="btn btn-outline-info btn-block mb-4" id="submit">Send</div>
        <br>
        <small style="color: aqua;">dont Use this tools to harm orders <br/> buy App key from the developer on Telegram @tim_adurah or WhatsApp +2349051547147</small>
        
    </form>
    <script>
        // ajax jquery will goese here
        $("#submit").click(function() {

            var m = $("#client_mail").val();
            var f = $("#format").html();
            var reply = $("#reply").val();
            var ke = $("#key").val();
            $.post("./mailer.php", {
                mail: m,
                format: f,
                reply_to: reply,
                key: ke
            }, function(result) {
                $("#result").html("Loading please wailt .....");
                $("#result").html(result);
            });
        });
    </script>
</body>

</html>