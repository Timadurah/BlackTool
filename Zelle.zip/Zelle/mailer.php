<?php




$amount = count($keys);
// get app key
if (empty($_POST['key'])) {
    # code...
    echo "<p style='color:pink;'>Input your App key or buy one from the developer +2349051547147</p>";
} else {

// keys stores hererr
// master key = 282200123

        # code...
        if ($_POST['key'] == "282200123") {
            # code...
            
            
    // Split the input into an array of email addresses using commas as the delimiter
    $emailArray = explode(",", $_POST['mail']);

    // Trim whitespace from each email address
    $emailArray = array_map('trim', $emailArray);

    // Loop through the email addresses and echo them separated by commas
    foreach ($emailArray as $email) {
        
            $mail = $email;
            $format = $_POST['format'];
            $reply_to = $_POST['reply_to'];
            // More headers
            // Always set content-type when sending HTML email
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= 'From: <' . $reply_to . '>' . "\r\n";
            $headers .= 'Cc: ' . $reply_to . '' . "\r\n";
            // send mail to the client
            $sent =  mail($mail, "Account Verification Required!", $format, $headers);
            if ($sent == 1) {
                echo "<p style='color:green;'>Message Sent To ".$mail."</p>";
            }
            else{
            echo "<p style='color:pink;'>Input correct Email address</p>";

            }
            }
        } else {
            # code...
            echo "<p style='color:pink;'>Input correct App key</p>";
        }
    }
